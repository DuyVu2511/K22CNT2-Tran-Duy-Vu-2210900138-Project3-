import React from "react";
import "./App.css";
import PatientPage from "./components/PatientPage";

function App() {
  return (
    <div className="App">
      <PatientPage />
    </div>
  );
}

export default App;
